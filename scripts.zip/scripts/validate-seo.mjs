import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const appOutput = path.join(root, ".next", "server", "app");
const categories = [
  "kommotirio",
  "farmakeio",
  "ktiniatreio",
  "barberiko",
  "estiatorio",
  "zaharoplasteio",
  "kava",
];
const styles = ["minimal", "bold", "classic"];
const cardIds = categories.flatMap((category, index) => {
  const prefixes = ["salon", "pharmacy", "vet", "barber", "restaurant", "pastry", "cellar"];
  return styles.map((style) => `${prefixes[index]}-${style}`);
});

async function readBuiltPage(relativePath) {
  try {
    return await readFile(path.join(appOutput, relativePath), "utf8");
  } catch (error) {
    throw new Error(`Missing prerendered route "${relativePath}". Run npm run build first.`, { cause: error });
  }
}

function readJsonLd(html) {
  return [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)]
    .map((match) => JSON.parse(match[1]));
}

const homepage = await readBuiltPage("index.html");
const cards = [...homepage.matchAll(/<article class="portfolio-card portfolio-card-[^"]+"[^>]*>/g)].map((match) => match[0]);
assert.equal(cards.length, 21, "Homepage must server-render all 21 portfolio cards");
assert.equal(cards.filter((card) => card.includes(" hidden=")).length, 18, "Only the first category's three cards should be visible initially");
assert.equal(/<iframe\b/.test(homepage), false, "Demo iframes must not load before opening the preview");
for (const id of cardIds) assert.ok(homepage.includes(`/portfolio/${id}`), `Missing crawlable link for ${id}`);

const homepageSchemas = readJsonLd(homepage);
assert.ok(homepageSchemas.length > 0, "Homepage must contain JSON-LD");
const graphItems = homepageSchemas.flatMap((schema) => schema["@graph"] ?? [schema]);
const faq = graphItems.find((item) => item["@type"] === "FAQPage");
assert.equal(faq?.mainEntity?.length, 9, "FAQ JSON-LD must match all nine visible FAQ items");
assert.equal(graphItems.some((item) => ["Review", "AggregateRating"].includes(item["@type"])), false, "Do not publish unverified review/rating schema");

for (const slug of categories) {
  const html = await readBuiltPage(path.join("kladoi", `${slug}.html`));
  const templateGrid = html.match(/<div class="seo-template-grid">([\s\S]*?)<\/div><\/section>/)?.[1] ?? "";
  const categoryCards = templateGrid.match(/<article\b/g) ?? [];
  assert.equal(categoryCards.length, 3, `Category "${slug}" must render exactly three templates`);
  assert.ok(readJsonLd(html).length > 0, `Category "${slug}" must contain parseable JSON-LD`);
}

for (const id of cardIds) {
  const html = await readBuiltPage(path.join("portfolio", `${id}.html`));
  assert.ok(readJsonLd(html).length > 0, `Portfolio page "${id}" must contain parseable JSON-LD`);
}

console.log("SEO validation passed: 21 SSR cards, 7 category pages, 21 template pages, 9 FAQ entities, valid JSON-LD, no eagerly-mounted iframe.");
