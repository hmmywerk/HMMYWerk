import { notFound } from "next/navigation";
import type { Metadata } from "next";
import DemoExperience from "@/components/demo-experience";
import { demos, getDemo } from "@/lib/demos";
import type { DemoStyle } from "@/data/demos";

type DemoPageProps = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ name?: string | string[]; style?: string | string[] }>;
};

export async function generateMetadata({ params, searchParams }: DemoPageProps): Promise<Metadata> {
  const [{ slug }, query] = await Promise.all([params, searchParams]);
  const demo = getDemo(slug);
  if (!demo) return {};

  const queryName = Array.isArray(query.name) ? query.name[0] : query.name;
  const name = queryName?.trim().slice(0, 60) || demo.shortTitle;
  return {
    title: `${name} | ${demo.title} · Πάτρα`,
    description: `${demo.description} Δείτε υπηρεσίες, πληροφορίες και πώς θα μας βρείτε στην Πάτρα.`,
    robots: { index: false, follow: false },
  };
}

export function generateStaticParams() {
  return demos.map(({ slug }) => ({ slug }));
}

export default async function DemoPage({ params, searchParams }: DemoPageProps) {
  const [{ slug }, query] = await Promise.all([params, searchParams]);
  const demo = getDemo(slug);

  if (!demo) notFound();

  const name = Array.isArray(query.name) ? query.name[0] : query.name;
  const requestedStyle = Array.isArray(query.style) ? query.style[0] : query.style;
  const style: DemoStyle = requestedStyle === "bold" || requestedStyle === "classic" ? requestedStyle : "minimal";

  return <DemoExperience demo={demo} businessName={name?.trim().slice(0, 60)} style={style} />;
}
