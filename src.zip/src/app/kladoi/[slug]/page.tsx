import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CATEGORIES, DEMOS, SITE_CONFIG, getCategory } from "@/data/demos";
import { getAbsoluteUrl, organizationJsonLd, serializeJsonLd } from "@/lib/seo";

type CategoryPageProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return CATEGORIES.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const { slug } = await params;
  const category = getCategory(slug);
  if (!category) return {};

  const canonical = getAbsoluteUrl(`/kladoi/${slug}`);
  return {
    title: `Ιστοσελίδα για ${category.nameEl}`,
    description: category.descriptionEl,
    keywords: [...category.seoKeywordsEl],
    alternates: canonical ? { canonical, languages: { "el-GR": canonical } } : undefined,
    openGraph: {
      type: "website",
      locale: "el_GR",
      title: `Ιστοσελίδα για ${category.nameEl} | ${SITE_CONFIG.brandName}`,
      description: category.descriptionEl,
      url: canonical,
    },
  };
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params;
  const category = getCategory(slug);
  if (!category) notFound();

  const demos = DEMOS.filter((demo) => demo.categorySlug === category.slug);
  const pageUrl = getAbsoluteUrl(`/kladoi/${slug}`);
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        "@id": pageUrl ? `${pageUrl}#page` : undefined,
        url: pageUrl,
        name: `Ιστοσελίδα για ${category.nameEl}`,
        description: category.descriptionEl,
        inLanguage: "el-GR",
        mainEntity: {
          "@type": "ItemList",
          itemListElement: demos.map((demo, index) => ({
            "@type": "ListItem",
            position: index + 1,
            url: getAbsoluteUrl(`/portfolio/${demo.id}`),
            name: demo.title,
          })),
        },
      },
      {
        "@type": "Service",
        "@id": pageUrl ? `${pageUrl}#service` : undefined,
        name: `Σχεδιασμός ιστοσελίδας για ${category.nameEl}`,
        serviceType: `Κατασκευή ιστοσελίδας για ${category.nameEl}`,
        description: category.descriptionEl,
        provider: { "@id": getAbsoluteUrl("/#organization"), name: SITE_CONFIG.brandName },
        areaServed: [
          { "@type": "City", name: "Πάτρα" },
          { "@type": "City", name: "Θεσσαλονίκη" },
          { "@type": "Country", name: "Ελλάδα" },
        ],
      },
      organizationJsonLd(),
    ],
  };

  return (
    <main className="seo-landing">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }} />
      <nav className="seo-breadcrumbs" aria-label="Διαδρομή σελίδας">
        <Link href="/">Αρχική</Link><span aria-hidden="true">/</span><span>{category.nameEl}</span>
      </nav>
      <header className="seo-landing-header">
        <Link href="/" className="seo-brand">{SITE_CONFIG.brandName}</Link>
        <span>ΣΧΕΔΙΑΣΜΟΣ ΙΣΤΟΣΕΛΙΔΩΝ ΓΙΑ ΤΟΠΙΚΕΣ ΕΠΙΧΕΙΡΗΣΕΙΣ</span>
        <h1>Ιστοσελίδα για {category.nameEl}</h1>
        <p>{category.descriptionEl}</p>
        <Link className="seo-primary-link" href={`/?category=${category.slug}#demos`}>Δες και τα τρία σχέδια</Link>
      </header>
      <section className="seo-template-list" aria-labelledby="seo-templates-title">
        <h2 id="seo-templates-title">Τρεις διαφορετικές σχεδιαστικές κατευθύνσεις</h2>
        <div className="seo-template-grid">
          {demos.map((demo) => (
            <article key={demo.id}>
              <Image src={demo.thumbnailUrl} alt={demo.alt} width={1200} height={800} sizes="(max-width: 760px) 100vw, 33vw" />
              <span>{demo.styleTag}</span>
              <h3><Link href={`/portfolio/${demo.id}`}>{demo.title}</Link></h3>
              <p>{demo.description}</p>
              <Link href={`/portfolio/${demo.id}`}>Πληροφορίες σχεδίου <span aria-hidden="true">→</span></Link>
            </article>
          ))}
        </div>
      </section>
      <section className="seo-category-cta">
        <h2>Έχεις επιχείρηση {category.nameEl.toLocaleLowerCase("el-GR")};</h2>
        <p>Μίλησέ μας για τις ανάγκες σου και θα συζητήσουμε ποια κατεύθυνση ταιριάζει στην επιχείρησή σου.</p>
        <Link href="/#contact">Ζήτησε προσφορά</Link>
      </section>
      <footer className="seo-landing-footer"><Link href="/">HMMYWERK</Link><Link href={`/?category=${category.slug}#demos`}>Όλα τα σχέδια της κατηγορίας</Link></footer>
    </main>
  );
}
