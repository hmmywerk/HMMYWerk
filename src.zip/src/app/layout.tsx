import type { Metadata } from "next";
import { getSiteUrl } from "@/lib/seo";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: getSiteUrl() ?? undefined,
  title: {
    default: "HMMYWERK | Ιστοσελίδες & Local SEO",
    template: "%s | HMMYWERK",
  },
  description:
    "Σύγχρονες ιστοσελίδες και Local SEO για επιχειρήσεις στην Πάτρα και τη Θεσσαλονίκη. Δείτε ζωντανά δείγματα, πακέτα και τρόπους συνεργασίας.",
  applicationName: "HMMYWERK",
  openGraph: {
    type: "website",
    locale: "el_GR",
    siteName: "HMMYWERK",
    title: "HMMYWERK | Ιστοσελίδες & Local SEO",
    description: "Σύγχρονες ιστοσελίδες και Local SEO για τοπικές επιχειρήσεις στην Ελλάδα.",
  },
  twitter: {
    card: "summary",
    title: "HMMYWERK | Ιστοσελίδες & Local SEO",
    description: "Σύγχρονες ιστοσελίδες και Local SEO για τοπικές επιχειρήσεις στην Ελλάδα.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="el">
      <body>{children}</body>
    </html>
  );
}
