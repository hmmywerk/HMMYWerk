import type { Metadata } from "next";
import AgencyHome from "@/components/agency-home";
import { FAQ, SITE_CONFIG } from "@/data/demos";
import { getAbsoluteUrl, organizationJsonLd, serializeJsonLd } from "@/lib/seo";

const homepageUrl = getAbsoluteUrl("/");

export const metadata: Metadata = {
  title: "Ιστοσελίδες για τοπικές επιχειρήσεις",
  description:
    "Σύγχρονες ιστοσελίδες και βασικό Local SEO για επιχειρήσεις στην Πάτρα, τη Θεσσαλονίκη και όλη την Ελλάδα. Δες 21 ζωντανά σχέδια.",
  alternates: homepageUrl ? { canonical: homepageUrl, languages: { "el-GR": homepageUrl } } : undefined,
};

export default function HomePage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        "@id": getAbsoluteUrl("/#website"),
        url: getAbsoluteUrl("/"),
        name: SITE_CONFIG.brandName,
        inLanguage: "el-GR",
      },
      organizationJsonLd(),
      {
        "@type": "FAQPage",
        mainEntity: FAQ.map(({ question, answer }) => ({
          "@type": "Question",
          name: question,
          acceptedAnswer: { "@type": "Answer", text: answer },
        })),
      },
    ],
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }} />
      <AgencyHome />
    </>
  );
}
