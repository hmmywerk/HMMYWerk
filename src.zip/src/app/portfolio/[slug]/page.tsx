import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { DEMOS, SITE_CONFIG, getPortfolioDemo, getDemoCategory } from "@/data/demos";
import { getAbsoluteUrl, serializeJsonLd } from "@/lib/seo";

type TemplatePageProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return DEMOS.map(({ id }) => ({ slug: id }));
}

export async function generateMetadata({ params }: TemplatePageProps): Promise<Metadata> {
  const { slug } = await params;
  const demo = getPortfolioDemo(slug);
  if (!demo) return {};

  const canonical = getAbsoluteUrl(`/portfolio/${slug}`);
  return {
    title: `${demo.title} — ${demo.styleTag}`,
    description: demo.description,
    alternates: canonical ? { canonical, languages: { "el-GR": canonical } } : undefined,
    openGraph: {
      type: "website",
      locale: "el_GR",
      title: `${demo.title} | ${SITE_CONFIG.brandName}`,
      description: demo.description,
      images: [{ url: demo.thumbnailUrl, width: 1200, height: 800, alt: demo.alt }],
      url: canonical,
    },
  };
}

export default async function TemplatePage({ params }: TemplatePageProps) {
  const { slug } = await params;
  const demo = getPortfolioDemo(slug);
  if (!demo) notFound();

  const category = getDemoCategory(demo);
  const pageUrl = getAbsoluteUrl(`/portfolio/${slug}`);
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    "@id": pageUrl ? `${pageUrl}#design` : undefined,
    url: pageUrl,
    name: demo.title,
    description: demo.description,
    image: demo.thumbnailUrl,
    genre: demo.styleTag,
    about: { "@type": "Thing", name: category.nameEl },
    inLanguage: "el-GR",
    creator: { "@type": "Organization", name: SITE_CONFIG.brandName, url: getAbsoluteUrl("/") },
  };

  return (
    <main className="seo-landing seo-template-page">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }} />
      <nav className="seo-breadcrumbs" aria-label="Διαδρομή σελίδας">
        <Link href="/">Αρχική</Link><span aria-hidden="true">/</span><Link href={`/kladoi/${category.slug}`}>{category.nameEl}</Link><span aria-hidden="true">/</span><span>{demo.title}</span>
      </nav>
      <article className="seo-template-detail">
        <div>
          <span className="seo-template-category">{category.nameEl} · {demo.styleTag}</span>
          <h1>{demo.title}</h1>
          <p>{demo.description}</p>
          <ul>{demo.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
          <div className="seo-template-actions">
            <Link className="seo-primary-link" href={demo.liveDemoUrl}>Άνοιγμα ζωντανού δείγματος</Link>
            <Link className="seo-secondary-link" href={`/?template=${encodeURIComponent(demo.id)}#contact`}>Ζήτησε προσφορά για αυτό το σχέδιο</Link>
          </div>
        </div>
        <Image src={demo.thumbnailUrl} alt={demo.alt} width={1200} height={800} sizes="(max-width: 760px) 100vw, 55vw" priority />
      </article>
      <footer className="seo-landing-footer"><Link href="/">HMMYWERK</Link><Link href={`/?category=${category.slug}#demos`}>Περισσότερα σχέδια για {category.nameEl.toLocaleLowerCase("el-GR")}</Link></footer>
    </main>
  );
}
