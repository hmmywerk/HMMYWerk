import type { MetadataRoute } from "next";
import { CATEGORIES, DEMOS } from "@/data/demos";
import { getAbsoluteUrl, getSiteUrl } from "@/lib/seo";

export default function sitemap(): MetadataRoute.Sitemap {
  if (!getSiteUrl()) return [];

  const homepage = getAbsoluteUrl("/");
  if (!homepage) return [];

  return [
    { url: homepage, changeFrequency: "monthly", priority: 1 },
    ...CATEGORIES.map((category) => ({
      url: getAbsoluteUrl(`/kladoi/${category.slug}`)!,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })),
    ...DEMOS.map((demo) => ({
      url: getAbsoluteUrl(`/portfolio/${demo.id}`)!,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
  ];
}
