"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState, type FormEvent } from "react";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Check,
  Clock3,
  Code2,
  MapPin,
  Menu,
  Search,
  Smartphone,
  Sparkles,
  Star,
  X,
} from "lucide-react";
import PortfolioShowcase from "@/components/portfolio-showcase";
import { DEMOS, FAQ, PRICING_TIERS, SITE_CONFIG, type PortfolioDemo } from "@/data/demos";

export default function AgencyHome() {
  const [businessName, setBusinessName] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [contactMessage, setContactMessage] = useState("");
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const selectedTemplate = DEMOS.find((demo) => demo.id === selectedTemplateId);

  useEffect(() => {
    const templateId = new URLSearchParams(window.location.search).get("template");
    const template = templateId ? DEMOS.find((demo) => demo.id === templateId) : undefined;
    const messageField = document.querySelector<HTMLTextAreaElement>("#contact-message");
    if (template && !messageField?.value.trim()) {
      setSelectedTemplateId(template.id);
      setContactMessage(`Ενδιαφέρομαι για το σχέδιο «${template.title}» (${template.category} · ${template.styleTag}). Θα ήθελα να συζητήσουμε την προσαρμογή του στην επιχείρησή μου.`);
    }
  }, []);

  function selectTemplate(demo: PortfolioDemo) {
    setSelectedTemplateId(demo.id);
    setContactMessage(`Ενδιαφέρομαι για το σχέδιο «${demo.title}» (${demo.category} · ${demo.styleTag}). Θα ήθελα να συζητήσουμε την προσαρμογή του στην επιχείρησή μου.`);
    const url = new URL(window.location.href);
    url.searchParams.set("template", demo.id);
    url.hash = "contact";
    window.history.replaceState(window.history.state, "", url);
    window.setTimeout(() => {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" });
      window.setTimeout(() => document.getElementById("contact-message")?.focus({ preventScroll: true }), 450);
    }, 0);
  }

  function submitContactForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const subject = "Νέο αίτημα για ιστοσελίδα";
    const body = [
      `Ονοματεπώνυμο: ${formData.get("name")}`,
      `Email: ${formData.get("email")}`,
      ...(selectedTemplate ? [`Σχέδιο: ${selectedTemplate.title} (${selectedTemplate.category})`] : []),
      "",
      String(formData.get("message") || ""),
    ].join("\n");
    window.location.href = `mailto:hmmywerk@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }

  return (
    <main className="showcase">
      <header className="showcase-header">
        <div className="showcase-nav-wrap">
          <Link className="showcase-brand" href="/" aria-label="HMMYWERK, αρχική σελίδα">
            <Image className="showcase-brand-mark" src="/hmmywerk-logo.png" width={35} height={35} alt="HMMYWERK" priority />
            <span>{SITE_CONFIG.brandName}<small>ΣΧΕΔΙΑΣΜΟΣ ΙΣΤΟΣΕΛΙΔΩΝ · ΤΟΠΙΚΟ SEO</small></span>
          </Link>
          <button className="showcase-menu-toggle" aria-label={mobileMenuOpen ? "Κλείσιμο μενού" : "Άνοιγμα μενού"} onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <nav className={mobileMenuOpen ? "showcase-nav is-open" : "showcase-nav"} aria-label="Κύρια πλοήγηση">
            <a href="#demos" onClick={() => setMobileMenuOpen(false)}>Τα δείγματα</a>
            <a href="#value" onClick={() => setMobileMenuOpen(false)}>Γιατί Τοπικό SEO</a>
            <a href="#process" onClick={() => setMobileMenuOpen(false)}>Η διαδικασία</a>
            <a href="#pricing" onClick={() => setMobileMenuOpen(false)}>Πακέτα</a>
          </nav>
          <a className="showcase-header-cta" href="#contact">Ας μιλήσουμε <ArrowUpRight size={15} /></a>
        </div>
      </header>

      <section className="showcase-hero">
        <div className="showcase-hero-glow" />
        <div className="showcase-hero-inner">
          <div className="showcase-hero-copy">
            <span className="showcase-badge"><span /> Πάτρα <i>•</i> Θεσσαλονίκη <i>•</i> Παράδοση σε 48 Ώρες</span>
            <h1>Σύγχρονες Ιστοσελίδες που Φέρνουν Πελάτες <em>από το Google &amp; το Κινητό</em></h1>
            <p>Δείτε έτοιμα, ζωντανά δείγματα για τον δικό σας κλάδο. Προσαρμόζουμε τη σελίδα στα χρώματα, τις φωτογραφίες και το όνομα ιστοσελίδας .gr μέσα σε 48 ώρες.</p>
            <div className="showcase-hero-actions">
              <a className="showcase-button showcase-button-amber" href="#demos">Δείτε τα live δείγματα <ArrowRight size={16} /></a>
              <a className="showcase-button showcase-button-glass" href="viber://chat?number=%2B306945441896">Επικοινωνία στο Viber <ArrowUpRight size={15} /></a>
            </div>
            <div className="showcase-hero-note"><span className="showcase-note-icon"><BadgeCheck size={17} /></span><span>Έτοιμη για κινητό, αναζήτηση και Google Maps<small>Σχεδιασμός με ξεκάθαρο στόχο: περισσότερες ουσιαστικές επαφές.</small></span></div>
          </div>
          <div className="showcase-hero-visual">
            <div className="showcase-hero-photo">
              <video
                className="showcase-hero-video"
                src="/live-coding.mp4"
                autoPlay
                loop
                muted
                playsInline
                preload="metadata"
                poster="/hero-poster.png"
                aria-label="Βίντεο σχεδιασμού και ανάπτυξης ιστοσελίδων"
              />
            </div>
            <div className="showcase-hero-caption"><span>01 / 07</span><span>Η δική σου επιχείρηση, στο προσκήνιο.</span></div>
          </div>
        </div>
        <div className="showcase-hero-bottom"><span>ΜΙΑ ΠΡΟΣΩΠΙΚΗ ΣΥΝΕΡΓΑΣΙΑ, ΑΠΟ ΤΗΝ ΠΡΩΤΗ ΙΔΕΑ ΜΕΧΡΙ ΤΟ LIVE</span><span>GR <b>·</b> EL <b>·</b> LOCAL</span></div>
      </section>

      <section className="showcase-intro-strip">
        <div className="showcase-content showcase-intro-inner">
          <span><Sparkles size={17} /> Δημιουργία με χαρακτήρα</span><span><Clock3 size={17} /> Παράδοση σε 48 ώρες*</span><span><MapPin size={17} /> Πάτρα &amp; Θεσσαλονίκη</span><span><Search size={17} /> Τοπικό SEO από την αρχή</span>
        </div>
      </section>

      <PortfolioShowcase businessName={businessName} onBusinessNameChange={setBusinessName} onSelectTemplate={selectTemplate} />

      <section className="showcase-value-section" id="value">
        <div className="showcase-content">
          <div className="showcase-section-heading">
            <div><span className="showcase-eyebrow">Η ΨΗΦΙΑΚΗ ΒΙΤΡΙΝΑ ΠΟΥ ΔΟΥΛΕΥΕΙ</span><h2>Ωραία σελίδα.<br /><em>Ουσιαστικό αποτέλεσμα.</em></h2></div>
            <p>Η παρουσία σου στο διαδίκτυο πρέπει να κάνει εύκολο το επόμενο βήμα — να σε βρουν, να σε εμπιστευτούν, να επικοινωνήσουν.</p>
          </div>
          <div className="showcase-value-grid">
            <article><span className="value-icon"><Smartphone size={19} /></span><span className="value-index">01 / ΕΜΠΕΙΡΙΑ</span><h3>Πρώτα το κινητό.</h3><p>Καθαρή πλοήγηση, ευανάγνωστο περιεχόμενο και άμεσες ενέργειες για όσους σε βρίσκουν από το τηλέφωνό τους.</p><span className="value-bottom">ΣΧΕΔΙΑΣΜΟΣ MOBILE-FIRST</span></article>
            <article><span className="value-icon"><MapPin size={19} /></span><span className="value-index">02 / ΤΟΠΙΚΗ ΑΝΑΖΗΤΗΣΗ</span><h3>Κοντά σε όσους σε ψάχνουν.</h3><p>Οργανωμένα στοιχεία, σωστή τοπική στόχευση και σύνδεση με το Google Maps βοηθούν τους πελάτες να σε εντοπίζουν.</p><span className="value-bottom">ΤΟΠΙΚΟ SEO · ΠΑΤΡΑ · ΘΕΣΣΑΛΟΝΙΚΗ</span></article>
            <article><span className="value-icon"><Code2 size={19} /></span><span className="value-index">03 / ΤΑΧΥΤΗΤΑ</span><h3>Γρήγορη και ουσιαστική.</h3><p>Ελαφριά, σύγχρονη υλοποίηση με ξεκάθαρη παρουσίαση υπηρεσιών και εύκολη επικοινωνία — χωρίς περιττά βήματα.</p><span className="value-bottom">ΣΑΦΗΣ ΠΛΗΡΟΦΟΡΙΑ · ΕΥΚΟΛΗ ΕΠΑΦΗ</span></article>
          </div>
        </div>
      </section>

      <section className="showcase-process-section" id="process">
        <div className="showcase-content">
          <div className="showcase-section-heading">
            <div><span className="showcase-eyebrow">ΑΠΟ ΤΟ ΔΕΙΓΜΑ ΣΤΟ LIVE</span><h2>Τρία βήματα.<br /><em>Καμία περιττή πολυπλοκότητα.</em></h2></div>
            <p>Ξέρεις τι γίνεται σε κάθε στάδιο. Συνεννοούμαστε απλά, με σαφές χρονοδιάγραμμα και συμφωνημένο κόστος.</p>
          </div>
          <div className="showcase-steps">
            {[["01", "Βλέπετε το δείγμα", "Επιλέγετε τον κλάδο και βλέπετε μια ολοκληρωμένη σχεδιαστική κατεύθυνση."], ["02", "Προσαρμογή σε 48 ώρες", "Προσθέτουμε όνομα, φωτογραφίες, περιεχόμενο και τις δικές σας υπηρεσίες."], ["03", "Δημοσίευση με .gr και Google Maps", "Συνδέουμε το όνομα ιστοσελίδας και οργανώνουμε τη σελίδα για την τοπική σας παρουσία."]].map(([number, title, body]) => <article key={number}><span className="showcase-step-number">{number}</span><span className="showcase-step-icon"><ArrowDownRight size={19} /></span><h3>{title}</h3><p>{body}</p></article>)}
          </div>
        </div>
      </section>

      <section className="showcase-section showcase-pricing" id="pricing">
        <div className="showcase-content">
          <div className="showcase-section-heading">
            <div><span className="showcase-eyebrow">ΚΑΘΑΡΕΣ ΕΠΙΛΟΓΕΣ · ΧΩΡΙΣ ΨΙΛΑ ΓΡΑΜΜΑΤΑ</span><h2>Μια καλή αρχή,<br /><em>στη σωστή κλίμακα.</em></h2></div>
            <p>Ενδεικτικά πακέτα για να ξέρεις από πού ξεκινάμε. Κάθε προσφορά επιβεβαιώνεται γραπτώς πριν αρχίσει η εργασία.</p>
          </div>
          <div className="showcase-pricing-grid">
            {PRICING_TIERS.map((item) => {
              const popular = item.id === "business-local-seo";
              return (
                <article className={popular ? "showcase-price-card is-popular" : "showcase-price-card"} key={item.id}>
                  {popular && <span className="showcase-popular-label"><Star size={12} fill="currentColor" /> ΠΛΗΡΗΣ ΤΟΠΙΚΗ ΠΑΡΟΥΣΙΑ</span>}
                  <span className="showcase-package-name">{item.name}</span><strong className="showcase-price">{item.priceFrom === null ? "Κατόπιν συζήτησης" : `${item.priceFrom}€`}</strong><p>{item.descriptionEl}</p>
                  <ul>{item.featuresEl.map((feature) => <li key={feature}><Check size={14} />{feature}</li>)}</ul>
                  <a href="#contact" className={popular ? "showcase-button showcase-button-dark" : "showcase-button showcase-button-light"}>Συζητάμε το project <ArrowRight size={15} /></a>
                </article>
              );
            })}
          </div>
          <p className="showcase-disclaimer">Οι τιμές είναι ενδεικτικές. Domain, φιλοξενία, ΦΠΑ και υπηρεσίες τρίτων αναφέρονται ξεχωριστά στην τελική προσφορά, όπου εφαρμόζεται.</p>
        </div>
      </section>

      <section className="showcase-faq-section" id="faq">
        <div className="showcase-content">
          <div className="showcase-section-heading">
            <div><span className="showcase-eyebrow">ΣΥΧΝΕΣ ΕΡΩΤΗΣΕΙΣ</span><h2>Όσα χρειάζεται<br /><em>να γνωρίζεις.</em></h2></div>
            <p>Καθαρές απαντήσεις για το κόστος, την παράδοση και το τι περιλαμβάνει κάθε συνεργασία.</p>
          </div>
          <div className="showcase-faq-list">
            {FAQ.map((item) => <details key={item.question}><summary>{item.question}<span aria-hidden="true">+</span></summary><p>{item.answer}</p></details>)}
          </div>
        </div>
      </section>

      <section className="showcase-contact" id="contact">
        <div className="showcase-content showcase-contact-inner">
          <div><span className="showcase-eyebrow">ΠΡΟΣΩΠΙΚΗ ΕΠΙΚΟΙΝΩΝΙΑ</span><h2>Έχεις μια ιδέα;<br /><em>Ας τη συζητήσουμε.</em></h2><p>Πες μου τι χρειάζεται η επιχείρησή σου. Θα σου απαντήσω προσωπικά, με καθαρή πρόταση και χωρίς πίεση.</p><form className="showcase-contact-form" onSubmit={submitContactForm}><label>Ονοματεπώνυμο<input name="name" autoComplete="name" required placeholder="Το όνομά σου" /></label><label>Email<input name="email" type="email" autoComplete="email" required placeholder="name@example.gr" /></label><label htmlFor="contact-message">Το μήνυμά σου{selectedTemplate && <span className="selected-template-chip" aria-live="polite">Επιλεγμένο σχέδιο: {selectedTemplate.title}</span>}<textarea id="contact-message" name="message" rows={4} required value={contactMessage} onChange={(event) => setContactMessage(event.target.value)} placeholder="Πες μου λίγα λόγια για την επιχείρησή σου ή το σχέδιο που σε ενδιαφέρει." /></label><input type="hidden" name="templateId" value={selectedTemplate?.id ?? ""} /><input type="hidden" name="templateName" value={selectedTemplate?.title ?? ""} /><button type="submit">Συνέχεια μέσω email <ArrowRight size={15} /></button><small>Το μήνυμα ανοίγει στην εφαρμογή email σου για αποστολή.</small></form></div>
          <div className="showcase-contact-card"><span className="contact-card-overline">ΣΧΕΔΙΑΣΜΟΣ ΙΣΤΟΣΕΛΙΔΩΝ · ΤΟΠΙΚΟ SEO</span><strong>HMMYWERK</strong><span>Πάτρα &amp; Θεσσαλονίκη</span><a href="tel:+306945441896" className="showcase-contact-link"><span>Τηλέφωνο 1</span><b>+30 694 544 1896 <ArrowUpRight size={15} /></b></a><a href="tel:+306986006940" className="showcase-contact-link"><span>Τηλέφωνο 2</span><b>+30 698 600 6940 <ArrowUpRight size={15} /></b></a><a href="viber://chat?number=%2B306945441896" className="showcase-contact-link"><span>Viber</span><b>Στείλε μήνυμα <ArrowUpRight size={15} /></b></a><a href="mailto:hmmywerk@gmail.com?subject=Νέο%20project%20ιστοσελίδας" className="showcase-contact-link"><span>Email</span><b>hmmywerk@gmail.com <ArrowUpRight size={15} /></b></a></div>
        </div>
      </section>
      <footer className="showcase-footer"><div className="showcase-content"><Link href="/" className="showcase-brand"><Image className="showcase-brand-mark" src="/hmmywerk-logo.png" width={35} height={35} alt="HMMYWERK" /><span>{SITE_CONFIG.brandName}<small>ΣΧΕΔΙΑΣΜΟΣ ΙΣΤΟΣΕΛΙΔΩΝ · ΤΟΠΙΚΟ SEO</small></span></Link><span>© {new Date().getFullYear()} {SITE_CONFIG.brandName} · Πάτρα &amp; Θεσσαλονίκη</span><a href="#top">Επιστροφή στην αρχή ↑</a></div></footer>
      <div className="showcase-mobile-actions"><a href="tel:+306945441896"><span>☎</span> Κλήση</a><a href="viber://chat?number=%2B306945441896"><span>◉</span> Viber</a><a href="#demos"><span>↗</span> Δείγματα</a></div>
    </main>
  );
}
