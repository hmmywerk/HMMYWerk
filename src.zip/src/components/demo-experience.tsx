"use client";

import Link from "next/link";
import Image from "next/image";
import { FormEvent, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Clock3,
  Heart,
  MapPin,
  PawPrint,
  Phone,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  X,
} from "lucide-react";
import type { Demo } from "@/lib/demos";
import type { DemoStyle } from "@/data/demos";

type Props = { demo: Demo; businessName?: string; style?: DemoStyle };

const imageIds: Record<string, string[]> = {
  kommotirio: ["photo-1560066984-138dadb4c035", "photo-1522337360788-8b13dee7a37e", "photo-1521590832167-7bcbfaa6381f"],
  barber: ["photo-1503951914875-452162b0f3f1", "photo-1621605815971-fbc98d665033", "photo-1517832606299-7ae9b720a186"],
  farmakeio: ["photo-1576091160399-112ba8d25d1d", "photo-1609840114035-3c981b782dfe", "photo-1559757148-5c350d0d3c56"],
  ktiniatreio: ["photo-1548199973-03cce0bbc87b", "photo-1551730459-92db2a308d6a", "photo-1516734212186-a967f81ad0d7"],
  estiatorio: ["photo-1414235077428-338989a2e8c0", "photo-1547592180-85f173990554", "photo-1540189549336-e6e99c3679fe"],
  zacharoplasteio: ["photo-1488477181946-6428a0291777", "photo-1578985545062-69928b1d9587", "photo-1551024506-0bccd828d307"],
  kava: ["photo-1510812431401-41d2bd2722f3", "photo-1516594798947-e65505dbb29d", "photo-1474722883778-792e7990302f"],
};

const categoryMap: Record<string, string[]> = {
  estiatorio: ["Όλα", "Πιάτα Ημέρας", "Ορεκτικά", "Κυρίως", "Σαλάτες"],
  kava: ["Όλα", "Ελληνικά Κρασιά", "Αποστάγματα", "Καλάθια Δώρων", "Delicatessen"],
};

const menuItems = [
  { title: "Γεμιστά φούρνου", category: "Πιάτα Ημέρας", description: "Ντομάτα και πιπεριά με ρύζι, μυρωδικά και φρέσκο ελαιόλαδο.", price: "8,50€", tag: "Νηστίσιμο" },
  { title: "Χειροποίητα ντολμαδάκια", category: "Ορεκτικά", description: "Με αμπελόφυλλο, μυρωδικά και δροσερό γιαούρτι.", price: "6,80€", tag: "Χειροποίητο" },
  { title: "Κοτόπουλο λεμονάτο", category: "Κυρίως", description: "Σιγομαγειρεμένο με πατάτες φούρνου και φρέσκο θυμάρι.", price: "10,50€", tag: "Αγαπημένο" },
  { title: "Σαλάτα κήπου", category: "Σαλάτες", description: "Εποχικά λαχανικά, μυζήθρα και βινεγκρέτ εσπεριδοειδών.", price: "7,20€", tag: "Εποχικό" },
  { title: "Μουσακάς ημέρας", category: "Πιάτα Ημέρας", description: "Με μελιτζάνα, πατάτα και βελούδινη μπεσαμέλ.", price: "10,00€", tag: "Σπιτικό" },
  { title: "Χωριάτικη σαλάτα", category: "Σαλάτες", description: "Ντομάτα, αγγούρι, ελιές και φέτα ΠΟΠ.", price: "8,00€", tag: "Κλασικό" },
];

const cellarItems = [
  { title: "Ασύρτικο · Σαντορίνη", category: "Ελληνικά Κρασιά", description: "Ορυκτότητα και φρεσκάδα από το ηφαιστειακό terroir.", price: "24€", tag: "Λευκό" },
  { title: "Ξινόμαυρο · Νάουσα", category: "Ελληνικά Κρασιά", description: "Κομψό ερυθρό με χαρακτήρα και δυνατότητα παλαίωσης.", price: "19€", tag: "Ερυθρό" },
  { title: "Τσίπουρο παλαίωσης", category: "Αποστάγματα", description: "Μικρή απόσταξη, ζεστός χαρακτήρας και μακρά επίγευση.", price: "32€", tag: "Ελληνικό" },
  { title: "Καλάθι γιορτής", category: "Καλάθια Δώρων", description: "Επιλεγμένο κρασί, χειροποίητα συνοδευτικά και κάρτα.", price: "από 38€", tag: "Δώρο" },
  { title: "Μέλι & παλαιωμένη γραβιέρα", category: "Delicatessen", description: "Δύο γεύσεις μικρών παραγωγών που ταιριάζουν υπέροχα.", price: "16€", tag: "Παραγωγοί" },
  { title: "Μοσχάτο · Σάμος", category: "Ελληνικά Κρασιά", description: "Αρωματικό και ισορροπημένο, ιδανικό για επιδόρπιο.", price: "18€", tag: "Γλυκό" },
];

const careTips = [
  ["Πότε χρειάζεται ο ετήσιος έλεγχος;", "Ο τακτικός έλεγχος προσαρμόζεται στην ηλικία, το ιστορικό και τις ανάγκες του ζώου σου. Μίλησε με τον κτηνίατρο για ένα πρόγραμμα πρόληψης."],
  ["Πώς προετοιμάζω το κατοικίδιο για την επίσκεψη;", "Έχε μαζί το βιβλιάριο υγείας, σημείωσε τυχόν αλλαγές στη συμπεριφορά ή την όρεξη και κράτησε τον σκύλο με λουρί ή τη γάτα σε ασφαλές κλουβί μεταφοράς."],
  ["Τι κάνω σε επείγουσα ανάγκη;", "Κάλεσε πριν ξεκινήσεις, ώστε να σε καθοδηγήσουμε και να προετοιμάσουμε την υποδοχή. Σε σοβαρό περιστατικό, μην καθυστερείς την αναζήτηση κτηνιατρικής βοήθειας."],
];

function Photo({ slug, index = 0, alt, className = "" }: { slug: string; index?: number; alt: string; className?: string }) {
  const image = imageIds[slug][index % imageIds[slug].length];
  return (
    <div className={`lux-photo lux-photo-${slug} ${className}`}>
      <div className="lux-photo-fallback" aria-hidden="true"><Sparkles size={25} /></div>
      <Image
        src={`https://images.unsplash.com/${image}?auto=format&fit=crop&w=1200&q=85`}
        width={1200}
        height={800}
        sizes="100vw"
        alt={alt}
        priority={index === 0}
        loading={index === 0 ? "eager" : "lazy"}
        onError={(event) => { event.currentTarget.style.display = "none"; }}
      />
      <span className="lux-photo-overlay" />
    </div>
  );
}

export default function DemoExperience({ demo, businessName, style = "minimal" }: Props) {
  const [barVisible, setBarVisible] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [filter, setFilter] = useState("Όλα");
  const [openTip, setOpenTip] = useState<number | null>(null);
  const name = businessName || demo.shortTitle;
  const isRestaurant = demo.slug === "estiatorio";
  const isCellar = demo.slug === "kava";
  const isCatalog = isRestaurant || isCellar;
  const filters = categoryMap[demo.slug] || [];
  const selectedCatalog = isRestaurant ? menuItems : cellarItems;
  const shownItems = useMemo(
    () => selectedCatalog.filter((item) => filter === "Όλα" || item.category === filter),
    [filter, selectedCatalog],
  );

  function submitInquiry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitted(true);
  }

  return (
    <main className={`lux-demo lux-${demo.slug} lux-style-${style}`}>
      {barVisible && <div className="lux-preview-bar"><div className="lux-preview-inner"><span><Sparkles size={14} /> Ζωντανό δείγμα κατασκευής <i>—</i> Θέλεις αυτή τη σελίδα με το δικό σου όνομα ιστοσελίδας .gr σε 48 ώρες;</span><div><a href="mailto:hmmywerk@gmail.com?subject=Νέο%20project">Επικοινωνία <ArrowUpRight size={13} /></a><Link href="/#demos"><ArrowLeft size={13} /> Όλα τα δείγματα</Link><button aria-label="Απόκρυψη μηνύματος" onClick={() => setBarVisible(false)}><X size={15} /></button></div></div></div>}

      <header className="lux-header">
        <Link href="/" className="lux-logo"><span className="lux-logo-mark">{demo.symbol}</span><span>{name}<small>{demo.category} · {demo.area}</small></span></Link>
        <nav><a href="#offerings">{isCatalog ? "Κατάλογος" : "Υπηρεσίες"}</a><a href="#story">{isRestaurant ? "Η φιλοσοφία μας" : "Η εμπειρία μας"}</a><a href="#find-us">Επικοινωνία</a></nav>
        <button className="lux-header-cta" onClick={() => setModalOpen(true)}>{demo.action} <ArrowUpRight size={15} /></button>
      </header>

      <section className="lux-hero">
        <Photo slug={demo.slug} alt={`Χαρακτηριστική εικόνα για ${name}`} className="lux-hero-photo" />
        <div className="lux-hero-shade" />
        <div className="lux-hero-content">
          <span className="lux-hero-kicker"><i /> {demo.eyebrow}</span>
          <h1>{demo.slug === "barber" ? <>Κλασική τέχνη.<br /><em>Σύγχρονο στυλ.</em></> : demo.slug === "farmakeio" ? <>Φροντίδα με γνώση.<br /><em>Δίπλα σου κάθε μέρα.</em></> : demo.slug === "ktiniatreio" ? <>Για τις πατούσες<br />που <em>αγαπάς.</em></> : demo.slug === "estiatorio" ? <>Γεύσεις που<br /><em>σε φέρνουν κοντά.</em></> : demo.slug === "zacharoplasteio" ? <>Μικρές στιγμές.<br /><em>Μεγάλη απόλαυση.</em></> : demo.slug === "kava" ? <>Κάθε φιάλη<br /><em>μια ιστορία.</em></> : <>Η δική σου στιγμή<br /><em>ομορφιάς.</em></>}<span className="lux-hero-title-brand">{name}</span></h1>
          <p>{demo.description}</p>
          <div className="lux-hero-actions"><button onClick={() => setModalOpen(true)}>{demo.action} <ArrowRight size={15} /></button><a href="#offerings">{isCatalog ? "Ανακάλυψε τον κατάλογο" : "Γνώρισε τον χώρο"} <ArrowDown size={14} /></a></div>
          <div className="lux-hero-rating"><span>★★★★★</span><b>4,9</b><small>Ενδεικτική βαθμολογία δείγματος</small></div>
        </div>
        <div className="lux-hero-location"><MapPin size={14} /><span>{demo.address}<small>{demo.area} · Ελλάδα</small></span></div>
      </section>

      {demo.slug === "farmakeio" && <div className="pharmacy-duty"><div><span className="duty-pulse" /><strong>Ανοιχτά Σήμερα</strong><span>Εξυπηρέτηση &amp; Συμβουλές Υγείας</span></div><a href="#find-us"><Clock3 size={15} /> Ωράριο &amp; πρόσβαση</a></div>}
      {demo.slug === "ktiniatreio" && <div className="vet-emergency"><div><span><Phone size={15} /></span><strong>Επείγον περιστατικό;</strong><small>Επικοινώνησε για καθοδήγηση και διαθεσιμότητα.</small></div><button onClick={() => setModalOpen(true)}>Επικοινωνία τώρα <ArrowRight size={14} /></button><span className="vet-emergency-note">24/7 ΔΕΙΓΜΑ ΥΠΗΡΕΣΙΑΣ</span></div>}

      {demo.slug === "kommotirio" && <section className="salon-intro" id="story"><div className="salon-intro-ornament">“</div><div><span className="lux-eyebrow">HAIR · BEAUTY · YOU</span><h2>Η ομορφιά δεν ακολουθεί κανόνες.<br /><em>Ακολουθεί εσένα.</em></h2><p>Ένας ήρεμος χώρος, μια ομάδα που ακούει και υπηρεσίες σχεδιασμένες γύρω από τη δική σου προσωπικότητα.</p></div><div className="salon-signature">Με φροντίδα,<br /><em>{name}</em></div></section>}

      {demo.slug === "barber" && <section className="barber-manifesto" id="story"><span className="lux-eyebrow">THE CRAFT · SINCE 2016</span><h2>Good cuts.<br /><em>Good company.</em></h2><p>Παραδοσιακή τεχνική, σύγχρονο αποτέλεσμα. Κάθε ραντεβού είναι χρόνος αφιερωμένος σε σένα.</p><div className="barber-products"><div><Photo slug="barber" index={1} alt="Προϊόντα ανδρικής περιποίησης barber" /><span>THE DAILY RITUAL<small>Περιποίηση με χαρακτήρα</small></span></div><div><Photo slug="barber" index={2} alt="Εργαλεία και ατμόσφαιρα barber shop" /><span>BUILT ON CRAFT<small>Η λεπτομέρεια κάνει τη διαφορά</small></span></div></div></section>}

      {demo.slug === "farmakeio" && <section className="pharmacy-intro" id="story"><span className="pharmacy-icon"><ShieldCheck size={26} /></span><div><span className="lux-eyebrow">ΥΓΕΙΑ · ΠΡΟΛΗΨΗ · ΦΡΟΝΤΙΔΑ</span><h2>Η συμβουλή που χρειάζεσαι,<br /><em>με ανθρώπινο ενδιαφέρον.</em></h2><p>Η επιστημονική ενημέρωση και η προσωπική εξυπηρέτηση συναντιούνται στο φαρμακείο της γειτονιάς σου.</p></div><a href="mailto:hmmywerk@gmail.com?subject=Ερώτηση%20φαρμακείου">Ρώτησε τον φαρμακοποιό <ArrowUpRight size={15} /></a></section>}

      {demo.slug === "ktiniatreio" && <section className="vet-intro" id="story"><div><span className="lux-eyebrow">PET CARE · ΠΡΟΛΗΨΗ · ΑΓΑΠΗ</span><h2>Μικροί φίλοι.<br /><em>Μεγάλη φροντίδα.</em></h2><p>Στεκόμαστε δίπλα σε κάθε κηδεμόνα με προληπτική φροντίδα, υπομονή και σαφείς συμβουλές για την υγεία του ζώου.</p><button onClick={() => setModalOpen(true)}>Κλείσε επίσκεψη <ArrowRight size={14} /></button></div><div className="vet-photo-pair"><Photo slug="ktiniatreio" index={1} alt="Σκύλος σε κτηνιατρική φροντίδα" /><Photo slug="ktiniatreio" index={2} alt="Χαρούμενο κατοικίδιο σε εξωτερικό χώρο" /></div></section>}

      {demo.slug === "estiatorio" && <section className="restaurant-intro" id="story"><span className="lux-eyebrow">ΑΠΟ ΤΗΝ ΚΟΥΖΙΝΑ ΜΑΣ</span><h2>Η απόλαυση της<br /><em>απλής, καλής γεύσης.</em></h2><p>Εποχικά υλικά, γνώριμες ελληνικές συνταγές και πιάτα που αλλάζουν με ό,τι καλύτερο φέρνει η αγορά.</p><a href="#offerings">Δες το σημερινό μενού <ArrowDown size={14} /></a><span className="restaurant-stamp">ΣΠΙΤΙΚΟ<br />ΚΑΘΗΜΕΡΙΝΑ <Heart size={15} /></span></section>}

      {demo.slug === "zacharoplasteio" && <section className="pastry-intro" id="story"><div><span className="lux-eyebrow">ΜΙΚΡΟ ΕΡΓΑΣΤΗΡΙ · ΜΕΓΑΛΗ ΑΓΑΠΗ</span><h2>Κάθε γιορτή<br /><em>θέλει το γλυκό της.</em></h2><p>Φτιάχνουμε καθημερινά μικρές απολαύσεις και τούρτες με τη δική σου ιδέα — από την πρώτη γεύση μέχρι την τελευταία λεπτομέρεια.</p><button onClick={() => setModalOpen(true)}>Σχεδίασε την τούρτα σου <ArrowRight size={14} /></button></div><Photo slug="zacharoplasteio" index={1} alt="Χειροποίητη τούρτα για ξεχωριστή περίσταση" /></section>}

      {demo.slug === "kava" && <section className="cellar-intro" id="story"><span className="lux-eyebrow">ΜΙΚΡΟΙ ΠΑΡΑΓΩΓΟΙ · ΜΕΓΑΛΕΣ ΙΣΤΟΡΙΕΣ</span><h2>Μια φιάλη για κάθε<br /><em>όμορφη αφορμή.</em></h2><p>Επιλεγμένος ελληνικός αμπελώνας, αποστάγματα και γεύσεις delicatessen — διαλεγμένα με περιέργεια και γνώση.</p><div className="cellar-pairing"><span className="pairing-icon">✳</span><span><b>Η πρόταση του sommelier</b><small>Ξινόμαυρο Νάουσας με παλαιωμένη γραβιέρα και κυδώνι.</small></span><ArrowUpRight size={15} /></div></section>}

      <section className={`lux-offerings lux-offerings-${demo.slug}`} id="offerings">
        <div className="lux-section-heading"><span className="lux-eyebrow">{isCatalog ? (isRestaurant ? "ΤΟ ΨΗΦΙΑΚΟ ΜΕΝΟΥ" : "Η ΕΠΙΛΟΓΗ ΤΟΥ ΚΕΛΑΡΙΟΥ") : "ΜΕ ΦΡΟΝΤΙΔΑ, ΓΙΑ ΣΕΝΑ"}</span><h2>{demo.slug === "kommotirio" ? <>Signature<br /><em>υπηρεσίες.</em></> : demo.slug === "barber" ? <>The service<br /><em>board.</em></> : demo.slug === "farmakeio" ? <>Ό,τι χρειάζεσαι,<br /><em>σε ένα σημείο.</em></> : demo.slug === "ktiniatreio" ? <>Φροντίδα σε<br /><em>κάθε στάδιο.</em></> : demo.slug === "estiatorio" ? <>Το σημερινό<br /><em>τραπέζι.</em></> : demo.slug === "zacharoplasteio" ? <>Οι δημιουργίες<br /><em>του εργαστηρίου.</em></> : <>Η κάβα<br /><em>μας.</em></>}</h2><p>{demo.listDescription}</p></div>
        {isCatalog ? <div className="catalog-layout">
          <div className="catalog-filter" role="group" aria-label="Φιλτράρισμα καταλόγου">{filters.map((item) => <button key={item} className={filter === item ? "is-active" : ""} onClick={() => setFilter(item)}>{item}</button>)}</div>
          <div className="catalog-grid">{shownItems.map((item, index) => <article className="catalog-card" key={item.title}><Photo slug={demo.slug} index={index} alt={item.title} /><div className="catalog-card-copy"><span>{item.tag}</span><h3>{item.title}</h3><p>{item.description}</p><strong>{item.price}</strong></div></article>)}</div>
        </div> : <div className="lux-service-list">{demo.services.map((service, index) => <article className="lux-service-row" key={service.name}><span className="lux-service-index">0{index + 1}</span><div><h3>{service.name}</h3><p>{service.detail}</p></div>{demo.slug === "kommotirio" && <span className="service-duration">{["45′", "150′", "90′", "60′"][index % 4]}</span>}<strong>{service.price}</strong><button aria-label={`Πληροφορίες για ${service.name}`} onClick={() => setModalOpen(true)}><ArrowUpRight size={16} /></button></article>)}</div>}
      </section>

      {demo.slug === "kommotirio" && <section className="salon-lookbook"><div className="lux-section-heading"><span className="lux-eyebrow">A LITTLE LOOKBOOK</span><h2>Έμπνευση για<br /><em>το επόμενο look.</em></h2></div><div className="salon-gallery"><Photo slug="kommotirio" index={1} alt="Ιδέα για χτένισμα από το lookbook" /><Photo slug="kommotirio" index={2} alt="Σύγχρονος χώρος hair studio" /><Photo slug="kommotirio" index={0} alt="Λεπτομέρεια υπηρεσίας styling" /></div><div className="salon-team"><div><span className="lux-eyebrow">Η ΟΜΑΔΑ ΜΑΣ</span><h3>Καλή αισθητική.<br /><em>Ακόμη καλύτερη ακρόαση.</em></h3></div><p>Οι άνθρωποι πίσω από κάθε αποτέλεσμα είναι πρώτα καλοί ακροατές. Μοιράσου μαζί μας τι έχεις στο μυαλό σου.</p><button onClick={() => setModalOpen(true)}>Γνώρισε την ομάδα <ArrowRight size={14} /></button></div></section>}

      {demo.slug === "farmakeio" && <section className="pharmacy-categories"><div className="lux-section-heading"><span className="lux-eyebrow">ΕΠΙΛΕΓΜΕΝΗ ΦΡΟΝΤΙΔΑ</span><h2>Καθημερινή υγεία,<br /><em>με σωστή καθοδήγηση.</em></h2></div><div className="pharmacy-category-grid">{[["01", "Δερμοκαλλυντικά", "Επιλογές ανάλογα με τις ανάγκες της επιδερμίδας σου.", "✳"], ["02", "Βιταμίνες", "Συμπληρώματα διατροφής και υπεύθυνη ενημέρωση.", "＋"], ["03", "Βρεφική Φροντίδα", "Προσεκτικά επιλεγμένα προϊόντα για τους μικρούς σας.", "♡"], ["04", "Ορθοπεδικά", "Βοηθήματα καθημερινής κίνησης και άνεσης.", "⌖"]].map(([number, title, copy, icon]) => <article key={number}><span>{number}</span><i>{icon}</i><h3>{title}</h3><p>{copy}</p><a href="mailto:hmmywerk@gmail.com?subject=Ερώτηση%20φαρμακείου">Ρώτησέ μας <ArrowRight size={13} /></a></article>)}</div><div className="pharmacy-advice"><span><ShieldCheck size={21} /></span><div><b>Χρειάζεσαι μια συμβουλή;</b><small>Επικοινώνησε με τον φαρμακοποιό για υπεύθυνη ενημέρωση.</small></div><a href="mailto:hmmywerk@gmail.com?subject=Συμβουλή%20φαρμακοποιού">Ρώτησε τώρα <ArrowUpRight size={14} /></a></div></section>}

      {demo.slug === "ktiniatreio" && <section className="vet-services-section"><div className="lux-section-heading"><span className="lux-eyebrow">ΟΛΟΚΛΗΡΩΜΕΝΗ ΚΤΗΝΙΑΤΡΙΚΗ ΦΡΟΝΤΙΔΑ</span><h2>Η υγεία τους,<br /><em>σε καλά χέρια.</em></h2></div><div className="vet-services-grid">{[["✳", "Προληπτικός Έλεγχος", "Για έγκαιρη φροντίδα σε κάθε ηλικία."], ["＋", "Εμβολιασμοί", "Εξατομικευμένο πρόγραμμα προστασίας."], ["⌕", "Υπέρηχος", "Διαγνωστικός έλεγχος με σύγχρονο εξοπλισμό."], ["♡", "Χειρουργική", "Υπεύθυνη φροντίδα πριν και μετά."], ["⌖", "Microchip", "Σήμανση και καταχώριση στοιχείων."], ["✦", "Διατροφή", "Συμβουλές για κάθε στάδιο ζωής."]].map(([icon, title, copy]) => <article key={title}><span>{icon}</span><h3>{title}</h3><p>{copy}</p><button onClick={() => setModalOpen(true)}>Μάθε περισσότερα <ArrowUpRight size={13} /></button></article>)}</div><div className="vet-tips"><div className="vet-tips-heading"><span className="lux-eyebrow">ΣΥΜΒΟΥΛΕΣ ΓΙΑ ΚΗΔΕΜΟΝΕΣ</span><h3>Μικρές απαντήσεις,<br /><em>μεγάλη σιγουριά.</em></h3><PawPrint size={26} /></div><div className="vet-accordion">{careTips.map(([title, copy], index) => <article className={openTip === index ? "is-open" : ""} key={title}><button onClick={() => setOpenTip(openTip === index ? null : index)} aria-expanded={openTip === index}><span>0{index + 1}</span>{title}<ChevronDown size={16} /></button>{openTip === index && <p>{copy}</p>}</article>)}</div></div></section>}

      {demo.slug === "estiatorio" && <section className="mealpass-section"><div className="mealpass-emblem">M<span>+</span></div><div><span className="lux-eyebrow">ΤΡΩΣ ΚΑΛΑ · ΚΕΡΔΙΖΕΙΣ ΠΕΡΙΣΣΟΤΕΡΑ</span><h2>Η Κάρτα Προνομίων<br />&amp; τα <em>πακέτα MealPass.</em></h2><p>Ένας πιο έξυπνος τρόπος να απολαμβάνεις τα αγαπημένα σου γεύματα. Ρώτησε για τις διαθέσιμες επιλογές προπληρωμένων πακέτων και προνομίων.</p><button onClick={() => setModalOpen(true)}>Μάθε για το MealPass <ArrowRight size={15} /></button></div><div className="mealpass-side">ΚΑΛΗ ΓΕΥΣΗ<br /><span>ΚΑΘΕ ΜΕΡΑ</span><Sparkles size={17} /></div></section>}

      {demo.slug === "zacharoplasteio" && <section className="pastry-creations"><div className="lux-section-heading"><span className="lux-eyebrow">ΧΕΙΡΟΠΟΙΗΤΕΣ ΔΗΜΙΟΥΡΓΙΕΣ</span><h2>Μια γλυκιά αφορμή<br /><em>για κάθε στιγμή.</em></h2></div><div className="pastry-creation-grid">{[["Τούρτες Γενεθλίων", "Μια γεύση, ένα σχέδιο, η δική σου ιστορία.", 1], ["Σιροπιαστά", "Φύλλο, σιρόπι και παράδοση σε ισορροπία.", 0], ["Παγωτό", "Φτιαγμένο στο εργαστήριο με εποχικές γεύσεις.", 2], ["Γλυκά Εκδηλώσεων", "Μικρές δημιουργίες για μεγάλες συγκεντρώσεις.", 1]].map(([title, copy, index]) => <button className="pastry-creation-card" key={String(title)} onClick={() => setModalOpen(true)}><Photo slug="zacharoplasteio" index={Number(index)} alt={String(title)} /><span><b>{title}</b><small>{copy}</small><i>Μάθε περισσότερα <ArrowUpRight size={13} /></i></span></button>)}</div></section>}

      {demo.slug === "kava" && <section className="cellar-gift"><span className="gift-box"><ShoppingBag size={24} /></span><div><span className="lux-eyebrow">ΕΤΑΙΡΙΚΑ ΔΩΡΑ · DELICATESSEN</span><h2>Ένα δώρο που<br /><em>λέει κάτι παραπάνω.</em></h2><p>Συνδυάζουμε κρασιά, αποστάγματα και προϊόντα μικρών παραγωγών σε προσεγμένα καλάθια. Για ανθρώπους και συνεργάτες που εκτιμούν τη λεπτομέρεια.</p><button onClick={() => setModalOpen(true)}>Σχεδίασε ένα καλάθι <ArrowRight size={14} /></button></div><Photo slug="kava" index={1} alt="Επιλεγμένο κρασί και συνοδευτικά για δώρο" /></section>}

      <section className="lux-review" id="reviews"><div className="lux-review-stars">★★★★★</div><span className="lux-eyebrow">Η ΕΜΠΕΙΡΙΑ ΤΩΝ ΠΕΛΑΤΩΝ</span><blockquote>«{demo.quote}»</blockquote><div className="lux-review-person"><span>{demo.customer.split(" ")[0].slice(0, 1)}</span><div><b>{businessName ? `Πελάτης της ${name}` : demo.customer}</b><small>Ενδεικτική κριτική δείγματος · 4,9 / 5</small></div></div></section>

      <section className="lux-find-us" id="find-us"><div className="lux-find-copy"><span className="lux-eyebrow">ΘΑ ΧΑΡΟΥΜΕ ΝΑ ΣΕ ΔΟΥΜΕ</span><h2>Η πόρτα μας<br /><em>είναι ανοιχτή.</em></h2><p>Δες πού βρισκόμαστε και έλα να γνωριστούμε. Για ραντεβού ή πληροφορίες, στείλε μας το αίτημά σου.</p><div className="lux-address"><MapPin size={17} /><span><b>{demo.address}</b><small>{demo.area} · Ελλάδα</small></span></div><div className="lux-phone-numbers"><a href="tel:+306945441896">+30 694 544 1896</a><a href="tel:+306986006940">+30 698 600 6940</a></div><div className="lux-find-actions"><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(demo.address)}`} target="_blank" rel="noreferrer">Άνοιγμα στο Google Maps <ArrowUpRight size={14} /></a><button onClick={() => setModalOpen(true)}>Επικοινωνία <ArrowRight size={14} /></button></div></div><div className="lux-map"><div className="lux-map-road road-a" /><div className="lux-map-road road-b" /><div className="lux-map-road road-c" /><span className="lux-map-park">ΠΛΑΤΕΙΑ</span><span className="lux-map-pin"><MapPin size={25} fill="currentColor" /></span><span className="lux-map-label">{name}<small>{demo.address}</small></span><span className="lux-map-caption">Χάρτης περιοχής · Ενδεικτική τοποθεσία</span></div></section>

      <footer className="lux-footer"><div><Link href="/" className="lux-footer-brand">{name}<small>{demo.category} · {demo.area}</small></Link><span>Δείγμα ιστοσελίδας από <Link href="/">Μάρκο Φιλιππάτο</Link></span></div><p>© {new Date().getFullYear()} {name}. Με επιφύλαξη παντός δικαιώματος.</p></footer>
      <div className="lux-sticky-actions"><a href="tel:+306945441896"><Phone size={16} /><span>Κλήση</span></a><a href="viber://chat?number=%2B306945441896"><span className="sticky-viber">◉</span><span>Viber</span></a><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(demo.address)}`} target="_blank" rel="noreferrer"><MapPin size={16} /><span>Χάρτης</span></a></div>

      {modalOpen && <div className="lux-modal-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) { setModalOpen(false); setSubmitted(false); } }}><section className="lux-modal" role="dialog" aria-modal="true" aria-labelledby="lux-modal-title"><button className="lux-modal-close" aria-label="Κλείσιμο" onClick={() => { setModalOpen(false); setSubmitted(false); }}><X size={19} /></button>{submitted ? <div className="lux-success"><span><Check size={25} /></span><span className="lux-eyebrow">ΤΟ ΑΙΤΗΜΑ ΚΑΤΑΧΩΡΗΘΗΚΕ</span><h2>Ευχαριστούμε!</h2><p>Αυτό είναι διαδραστικό δείγμα. Δεν αποστέλλονται ούτε αποθηκεύονται προσωπικά στοιχεία.</p><button onClick={() => { setModalOpen(false); setSubmitted(false); }}>Κλείσιμο</button></div> : <><span className="lux-eyebrow">{demo.slug === "zacharoplasteio" ? "CUSTOM CAKE / EVENT ORDER" : demo.slug === "barber" ? "BARBER BOOKING" : demo.slug === "ktiniatreio" ? "ΚΛΕΙΣΕ ΕΠΙΣΚΕΨΗ" : demo.slug === "farmakeio" ? "ΕΠΙΚΟΙΝΩΝΙΑ ΜΕ ΤΟ ΦΑΡΜΑΚΕΙΟ" : isCatalog ? "ΕΠΙΚΟΙΝΩΝΙΑ / ΠΑΡΑΓΓΕΛΙΑ" : "ΑΙΤΗΜΑ ΡΑΝΤΕΒΟΥ"}</span><h2 id="lux-modal-title">{demo.slug === "zacharoplasteio" ? "Πες μας τη γλυκιά σου ιδέα." : demo.slug === "ktiniatreio" ? "Πώς να φροντίσουμε τον φίλο σου;" : demo.slug === "barber" ? "Κλείσε την ώρα σου." : isCatalog ? "Τι θα θέλατε να ανακαλύψετε;" : "Ας βρούμε την ώρα σου."}</h2><p>Συμπλήρωσε τα στοιχεία και θα επικοινωνήσουμε για επιβεβαίωση. Πρόκειται για demo φόρμα.</p><form onSubmit={submitInquiry}>
          <label>Ονοματεπώνυμο<input name="name" autoComplete="name" required placeholder="Το όνομά σου" /></label>
          <label>Τηλέφωνο<input name="phone" type="tel" autoComplete="tel" required placeholder="Τηλέφωνο επικοινωνίας" /></label>
          {demo.slug === "barber" && <label>Barber<select name="barber" defaultValue="" required><option value="" disabled>Επίλεξε barber</option><option>Όποιος είναι διαθέσιμος</option><option>Ο barber της επιλογής μου</option></select></label>}
          {demo.slug === "ktiniatreio" && <><label>Τύπος κατοικιδίου<select name="pet" required defaultValue=""><option value="" disabled>Επίλεξε</option><option>Σκύλος</option><option>Γάτα</option><option>Άλλο</option></select></label><label>Λόγος επίσκεψης<input name="reason" required placeholder="π.χ. Προληπτικός έλεγχος" /></label></>}
          {demo.slug === "kommotirio" && <><label>Υπηρεσία<select name="service" required defaultValue=""><option value="" disabled>Επίλεξε υπηρεσία</option><option>Κούρεμα &amp; styling</option><option>Balayage</option><option>Θεραπεία κερατίνης</option></select></label><div className="lux-form-row"><label>Ημέρα<input type="date" name="date" required min={new Date().toISOString().slice(0, 10)} /></label><label>Ώρα<select name="time" required defaultValue=""><option value="" disabled>Επίλεξε</option><option>10:00</option><option>12:00</option><option>15:00</option><option>17:30</option></select></label></div></>}
          {demo.slug === "zacharoplasteio" && <><label>Γεύση / είδος γλυκού<input name="flavor" required placeholder="π.χ. Σοκολάτα, red velvet..." /></label><div className="lux-form-row"><label>Μερίδες<input type="number" name="portions" min="4" required placeholder="π.χ. 12" /></label><label>Ημερομηνία<input type="date" name="date" required min={new Date().toISOString().slice(0, 10)} /></label></div></>}
          {(isRestaurant || isCellar) && <label>Τι σε ενδιαφέρει;<textarea name="request" rows={3} required placeholder={isRestaurant ? "Κράτηση, takeaway ή ερώτηση για το μενού..." : "Κρασί, εταιρικό καλάθι ή άλλη επιλογή..."} /></label>}
          {demo.slug === "barber" && <label>Υπηρεσία<select name="service" required defaultValue=""><option value="" disabled>Επίλεξε υπηρεσία</option><option>Κούρεμα</option><option>Κούρεμα &amp; περιποίηση γενειάδας</option><option>Παραδοσιακό ξύρισμα</option></select></label>}
          {demo.slug === "farmakeio" && <label>Πώς μπορούμε να βοηθήσουμε;<textarea name="request" rows={3} required placeholder="Γράψε μας την ερώτησή σου..." /></label>}
          {demo.slug === "ktiniatreio" && <label>Ημέρα που σε βολεύει<input type="date" name="date" required min={new Date().toISOString().slice(0, 10)} /></label>}
          {demo.slug === "barber" && <div className="lux-form-row"><label>Ημέρα<input type="date" name="date" required min={new Date().toISOString().slice(0, 10)} /></label><label>Ώρα<select name="time" required defaultValue=""><option value="" disabled>Επίλεξε</option><option>10:00</option><option>12:00</option><option>15:00</option><option>17:30</option></select></label></div>}
          {demo.slug === "kava" && <label>Τηλέφωνο ή email για επικοινωνία<input name="contact" required placeholder="Πώς να επικοινωνήσουμε;" /></label>}
          <button type="submit" className="lux-submit">{demo.slug === "zacharoplasteio" ? "Στείλε αίτημα παραγγελίας" : isCatalog ? "Στείλε αίτημα" : "Ζήτησε επιβεβαίωση"} <ArrowRight size={15} /></button>
          <small className="lux-privacy-note"><ShieldCheck size={12} /> Τα στοιχεία δεν αποστέλλονται ή αποθηκεύονται. Δοκιμαστική φόρμα επίδειξης.</small>
        </form></>}</section></div>}
    </main>
  );
}
