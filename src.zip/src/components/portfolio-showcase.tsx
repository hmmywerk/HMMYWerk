"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Check,
  ExternalLink,
  LoaderCircle,
  Monitor,
  RefreshCw,
  Smartphone,
  Tablet,
  X,
} from "lucide-react";
import { CATEGORIES, DEMOS, type PortfolioDemo } from "@/data/demos";

type Props = {
  businessName: string;
  onBusinessNameChange: (value: string) => void;
  onSelectTemplate: (demo: PortfolioDemo) => void;
};

type Viewport = "desktop" | "tablet" | "mobile";

const viewportOptions: { id: Viewport; label: string; width: string; icon: typeof Monitor }[] = [
  { id: "desktop", label: "Υπολογιστής", width: "100%", icon: Monitor },
  { id: "tablet", label: "Τάμπλετ", width: "768px", icon: Tablet },
  { id: "mobile", label: "Κινητό", width: "375px", icon: Smartphone },
];

export default function PortfolioShowcase({ businessName, onBusinessNameChange, onSelectTemplate }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<string>(CATEGORIES[0].slug);
  const [activeDemo, setActiveDemo] = useState<PortfolioDemo | null>(null);
  const [viewport, setViewport] = useState<Viewport>("desktop");
  const [isLoading, setIsLoading] = useState(false);
  const [loadFailed, setLoadFailed] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  const previewUrl = useMemo(() => {
    if (!activeDemo || typeof window === "undefined") return "";
    const url = new URL(activeDemo.liveDemoUrl, window.location.origin);
    const name = businessName.trim();
    if (name) url.searchParams.set("name", name);
    return url.toString();
  }, [activeDemo, businessName]);

  useEffect(() => {
    const categoryFromUrl = new URLSearchParams(window.location.search).get("category");
    if (categoryFromUrl && CATEGORIES.some((category) => category.slug === categoryFromUrl)) {
      setSelectedCategory(categoryFromUrl);
    }
  }, []);

  useEffect(() => {
    if (!activeDemo) return;
    document.body.style.overflow = "hidden";
    closeButtonRef.current?.focus();
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActiveDemo(null);
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [activeDemo]);

  useEffect(() => {
    if (!activeDemo || !isLoading) return;
    const timeout = window.setTimeout(() => {
      setIsLoading(false);
      setLoadFailed(true);
    }, 12000);
    return () => window.clearTimeout(timeout);
  }, [activeDemo, isLoading]);

  function openDemo(demo: PortfolioDemo) {
    setViewport("desktop");
    setLoadFailed(false);
    setIsLoading(true);
    setActiveDemo(demo);
  }

  function chooseCategory(slug: string) {
    setSelectedCategory(slug);
    const url = new URL(window.location.href);
    url.searchParams.set("category", slug);
    window.history.replaceState(window.history.state, "", url);
  }

  function selectDemo() {
    if (!activeDemo) return;
    const selected = activeDemo;
    setActiveDemo(null);
    onSelectTemplate(selected);
  }

  function retryDemo() {
    setLoadFailed(false);
    setIsLoading(true);
    setReloadKey((value) => value + 1);
  }

  return (
    <>
      <section className="showcase-section showcase-demos" id="demos">
        <div className="showcase-content">
          <div className="showcase-section-heading">
            <div>
              <span className="showcase-eyebrow">ΕΠΤΑ ΚΛΑΔΟΙ · 21 ΣΧΕΔΙΑ</span>
              <h2>Η πρώτη ματιά<br />στην <em>επόμενη εκδοχή σου.</em></h2>
            </div>
            <p>Διάλεξε τον κλάδο σου και εξερεύνησε τρεις διαφορετικές σχεδιαστικές κατευθύνσεις. Κάθε δείγμα είναι προσαρμοσμένο στις ανάγκες μιας τοπικής επιχείρησης.</p>
          </div>

          <div className="brand-preview-bar">
            <div className="brand-preview-copy">
              <span aria-hidden="true">✦</span>
              <div><label htmlFor="business-name">Δες το όνομα της επιχείρησής σου στα δείγματα</label><small>Προαιρετικό — εμφανίζεται και στις ζωντανές προεπισκοπήσεις.</small></div>
            </div>
            <div className="brand-preview-input">
              <input id="business-name" value={businessName} onChange={(event) => onBusinessNameChange(event.target.value)} placeholder="π.χ. Το Κατάστημά σου, Πάτρα" maxLength={60} />
            </div>
          </div>

          <div className="portfolio-category-scroll" role="group" aria-label="Επιλογή κατηγορίας επιχείρησης">
            {CATEGORIES.map((category) => (
              <button
                type="button"
                key={category.slug}
                className={`portfolio-category-pill${selectedCategory === category.slug ? " is-active" : ""}`}
                aria-pressed={selectedCategory === category.slug}
                onClick={() => chooseCategory(category.slug)}
              >
                {category.nameEl}
              </button>
            ))}
          </div>
          <nav className="portfolio-category-pages" aria-label="Σελίδες ανά επαγγελματικό κλάδο">
            <span>Περισσότερα για:</span>
            {CATEGORIES.map((category) => <Link href={`/kladoi/${category.slug}`} key={category.slug}>{category.nameEl}</Link>)}
          </nav>

          <div className="portfolio-grid" aria-live="polite">
            {DEMOS.map((demo, index) => (
              <article className={`portfolio-card portfolio-card-${demo.style}`} key={demo.id} hidden={demo.categorySlug !== selectedCategory}>
                <div className="portfolio-browser">
                  <div className="portfolio-browser-bar" aria-hidden="true">
                    <span className="portfolio-browser-dots"><i /><i /><i /></span>
                    <span className="portfolio-browser-address">www.{demo.id}.gr</span>
                    <span className="portfolio-browser-lock">●</span>
                  </div>
                  <div className="portfolio-thumbnail">
                    <div className="portfolio-thumbnail-fallback" aria-hidden="true">{demo.category}</div>
                    <Image
                      src={demo.thumbnailUrl}
                      alt={demo.alt}
                      width={1200}
                      height={800}
                      sizes="(max-width: 760px) 100vw, (max-width: 1100px) 50vw, 33vw"
                      loading={index === 0 ? "eager" : "lazy"}
                      priority={index === 0}
                      onError={(event) => { event.currentTarget.style.display = "none"; }}
                    />
                    <span className="portfolio-style-badge">{demo.styleTag}</span>
                    <span className="portfolio-thumbnail-title">{businessName.trim() || demo.title}</span>
                  </div>
                </div>
                <div className="portfolio-card-content">
                  <span className="portfolio-card-category">{demo.category}</span>
                  <h3><Link href={`/portfolio/${demo.id}`}>{demo.title}</Link></h3>
                  <span className="portfolio-card-vibe">{demo.styleTag}</span>
                  <p>{demo.description}</p>
                  <ul className="portfolio-benefits">
                    {demo.features.map((feature) => <li key={feature}><Check size={14} aria-hidden="true" />{feature}</li>)}
                  </ul>
                  <div className="portfolio-card-actions">
                    <button type="button" className="portfolio-live-button" onClick={() => openDemo(demo)}>Live Demo <ArrowRight size={15} /></button>
                    <button type="button" className="portfolio-quote-button" onClick={() => onSelectTemplate(demo)}>Ζήτα Προσφορά</button>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <p className="showcase-disclaimer">Τα δείγματα είναι ενδεικτικές σχεδιαστικές προτάσεις και προσαρμόζονται στην ταυτότητα και τις ανάγκες κάθε επιχείρησης.</p>
        </div>
      </section>

      {activeDemo && (
        <div className="portfolio-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setActiveDemo(null); }}>
          <section className="portfolio-modal" role="dialog" aria-modal="true" aria-labelledby="portfolio-modal-title">
            <header className="portfolio-modal-header">
              <div className="portfolio-modal-heading">
                <div><h2 id="portfolio-modal-title">{activeDemo.title}</h2><span className="portfolio-modal-category">{activeDemo.category} · {activeDemo.styleTag}</span></div>
              </div>
              <div className="portfolio-device-switcher" role="group" aria-label="Προσαρμογή μεγέθους προεπισκόπησης">
                {viewportOptions.map(({ id, label, icon: Icon }) => (
                  <button type="button" key={id} className={viewport === id ? "is-active" : ""} aria-label={label} aria-pressed={viewport === id} onClick={() => setViewport(id)}>
                    <Icon size={16} /><span>{label}</span>
                  </button>
                ))}
              </div>
              <a className="portfolio-open-new" href={previewUrl} target="_blank" rel="noreferrer"><ExternalLink size={16} /><span>Νέα καρτέλα</span></a>
              <button ref={closeButtonRef} className="portfolio-modal-close" type="button" aria-label="Κλείσιμο προεπισκόπησης" onClick={() => setActiveDemo(null)}><X size={20} /></button>
            </header>
            <div className="portfolio-preview-stage">
              <div className="portfolio-iframe-frame" style={{ width: viewportOptions.find((option) => option.id === viewport)?.width }}>
                {isLoading && <div className="portfolio-preview-loading"><LoaderCircle size={29} />                <span>Φορτώνει η ζωντανή προεπισκόπηση…</span></div>}
                {loadFailed && (
                  <div className="portfolio-preview-fallback">
                    <span>Η προεπισκόπηση δεν φόρτωσε εδώ.</span>
                    <p>Ορισμένες ρυθμίσεις ασφαλείας δεν επιτρέπουν την εμφάνιση μιας ιστοσελίδας μέσα σε πλαίσιο.</p>
                    <div><a href={previewUrl} target="_blank" rel="noreferrer"><ExternalLink size={15} /> Άνοιγμα σε νέα καρτέλα</a><button type="button" onClick={retryDemo}><RefreshCw size={15} /> Νέα προσπάθεια</button></div>
                  </div>
                )}
                <iframe
                  key={`${previewUrl}-${reloadKey}`}
                  title={`Ζωντανή προεπισκόπηση: ${activeDemo.title}`}
                  src={previewUrl}
                  loading="lazy"
                  sandbox="allow-scripts allow-forms"
                  onLoad={() => { setIsLoading(false); setLoadFailed(false); }}
                  onError={() => { setIsLoading(false); setLoadFailed(true); }}
                />
              </div>
            </div>
            <footer className="portfolio-modal-footer">
              <span>Δες πώς προσαρμόζεται το σχέδιο σε κάθε οθόνη.</span>
              <button type="button" onClick={selectDemo}>Επιλογή αυτού του σχεδίου <ArrowRight size={16} /></button>
            </footer>
          </section>
        </div>
      )}
    </>
  );
}
