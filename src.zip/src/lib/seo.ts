import { SITE_CONFIG } from "@/data/demos";

export function getSiteUrl(): URL | null {
  if (!SITE_CONFIG.siteUrl) return null;

  try {
    const url = new URL(SITE_CONFIG.siteUrl);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    if (
      url.hostname === "localhost" ||
      url.hostname.endsWith(".example") ||
      url.hostname.startsWith("replace-with-")
    ) return null;
    return url;
  } catch {
    return null;
  }
}

export function getAbsoluteUrl(path: string): string | undefined {
  const siteUrl = getSiteUrl();
  return siteUrl ? new URL(path, siteUrl).toString() : undefined;
}

export function serializeJsonLd(value: unknown): string {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}

export function organizationJsonLd() {
  return {
    "@type": "ProfessionalService",
    "@id": getAbsoluteUrl("/#organization"),
    name: SITE_CONFIG.brandName,
    ...(SITE_CONFIG.legalName.startsWith("REPLACE_") ? {} : { legalName: SITE_CONFIG.legalName }),
    email: SITE_CONFIG.email,
    telephone: SITE_CONFIG.phone,
    areaServed: [
      { "@type": "City", name: "Πάτρα" },
      { "@type": "City", name: "Θεσσαλονίκη" },
      { "@type": "Country", name: "Ελλάδα" },
    ],
    knowsLanguage: "el",
  };
}
